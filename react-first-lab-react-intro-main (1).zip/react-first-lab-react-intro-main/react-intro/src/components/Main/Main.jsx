import "./Main.css";

function Main() {
  return (
    <main className="main">
      <h1>Мій перший React-проєкт</h1>
      <p>
        Це компонент Main. Тут може бути ваш текст, опис сайту або інформація
        про лабораторну роботу.
      </p>
      <button className="main-btn">Натисни мене</button>
    </main>
  );
}

export default Main;